package com.akashali.blockchainexample;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView blocks_RV;
    List<Block> Blockchain;
    BlockListAdapter adapter;
    List<Integer> hashes;
    ImageView addBlock;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        hashes=new ArrayList<>();
        Blockchain=new ArrayList<>();
        addBlock=findViewById(R.id.addBlock);
        addBlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder promote_service_dialog=new AlertDialog.Builder(MainActivity.this);
                View promoteView=getLayoutInflater().inflate(R.layout.add_block_dialog_box,null);
                final MaterialButton cancel=(MaterialButton)promoteView.findViewById(R.id.cancel);
                final MaterialButton add=(MaterialButton)promoteView.findViewById(R.id.add);
                final TextInputEditText getData=(TextInputEditText)promoteView.findViewById(R.id.getData);
                promote_service_dialog.setView(promoteView);
                final AlertDialog alertDialog=promote_service_dialog.create();
                alertDialog.setCanceledOnTouchOutside(false);
                alertDialog.show();

                add.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String data=getData.getText().toString();
                        String timestamp= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
                        Blockchain.add(new Block("Block "+ Integer.toString(Blockchain.size()),timestamp,data,Blockchain.get(Blockchain.size()-1).getHash(),"Verified"));
                        hashes.add(Blockchain.get(Blockchain.size()-1).getHash());
                        adapter.notifyDataSetChanged();
                        Toast.makeText(MainActivity.this,"Block added successfully.",Toast.LENGTH_SHORT).show();
                        alertDialog.dismiss();
                        Log.d("Hash", Blockchain.toString());
                    }
                });
                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.dismiss();
                    }
                });
            }
        });

        blocks_RV=findViewById(R.id.blocks_RV);
        RecyclerView.LayoutManager lm= new LinearLayoutManager(this);
        blocks_RV.setLayoutManager(lm);
        adapter=new BlockListAdapter(Blockchain,this);
        blocks_RV.setAdapter(adapter);
        adapter.setOnItemClickListener(new BlockListAdapter.OnItemClickListener(){
            @Override
            public void onItemClick(int position) {
                final AlertDialog.Builder promote_service_dialog=new AlertDialog.Builder(MainActivity.this);
                View promoteView=getLayoutInflater().inflate(R.layout.add_block_dialog_box,null);
                final TextView addBlock=(TextView)promoteView.findViewById(R.id.addBlock);
                final MaterialButton cancel=(MaterialButton)promoteView.findViewById(R.id.cancel);
                final MaterialButton add=(MaterialButton)promoteView.findViewById(R.id.add);
                final TextInputEditText getData=(TextInputEditText)promoteView.findViewById(R.id.getData);
                promote_service_dialog.setView(promoteView);
                final AlertDialog alertDialog=promote_service_dialog.create();
                alertDialog.setCanceledOnTouchOutside(false);
                getData.setText(Blockchain.get(position).getData());
                addBlock.setText("Edit Block");
                add.setText("SAVE");
                alertDialog.show();
                add.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String data=getData.getText().toString();
                        String timestamp= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
                        Blockchain.get(position).editBlock(data,timestamp);
                        adapter.notifyDataSetChanged();
                        Toast.makeText(MainActivity.this,"Block edited successfully.",Toast.LENGTH_SHORT).show();
                        for (int i=1;i<Blockchain.size();i++)
                        {
                            Blockchain.get(i).setHash(Blockchain.get(i-1).getHash());
                        }
                        for (int i=0; i<Blockchain.size();i++)
                        {
                            if (!(Blockchain.get(i).getHash().equals(hashes.get(i))))
                            {
                                Log.d("Hash", Integer.toString(hashes.get(i)));
                                Blockchain.get(i).setIsVerified("Corrupted");
                            }
                        }
                        alertDialog.dismiss();
                        Log.d("Hash", Blockchain.toString());
                    }
                });
                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.dismiss();
                    }
                });

            }
        });

        Block firstBlock=new Block("Block 0","14/4/2021","Secret Message",0,"Verified");
        Blockchain.add(firstBlock);
        hashes.add(firstBlock.getHash());

    }
}