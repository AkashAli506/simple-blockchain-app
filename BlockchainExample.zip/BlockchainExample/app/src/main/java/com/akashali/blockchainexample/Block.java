package com.akashali.blockchainexample;


import java.util.Arrays;

public class Block {
    String index;
    String timeStamp;
    String data;
    Integer hash;
    Integer previousHash;
    String isVerified;

    public Block(String index, String timeStamp, String data, Integer previousHash,String isVerified) {
        this.index = index;
        this.timeStamp = timeStamp;
        this.data = data;
        this.previousHash = previousHash;
        this.isVerified=isVerified;
        this.hash= Arrays.hashCode(new int[]{this.timeStamp.hashCode(),this.data.hashCode(),this.previousHash});
    }

    public void editBlock(String data, String timeStamp){
        this.data = data;
        this.timeStamp=timeStamp;
        this.hash= Arrays.hashCode(new int[]{this.timeStamp.hashCode(),this.data.hashCode(),this.previousHash});
    }

    @Override
    public String toString() {
        return "Block{" +
                "index='" + index + '\'' +
                ", timeStamp='" + timeStamp + '\'' +
                ", data='" + data + '\'' +
                ", hash=" + hash +
                ", previousHash=" + previousHash +
                ", isVerified='" + isVerified + '\'' +
                '}';
    }

    public String getIsVerified() {
        return isVerified;
    }

    public void setIsVerified(String isVerified) {
        this.isVerified = isVerified;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Integer getHash() {
        return hash;
    }

    public void setHash(Integer previousHash) {
        this.previousHash=previousHash;
        this.hash = Arrays.hashCode(new int[]{this.timeStamp.hashCode(),this.data.hashCode(),this.previousHash});
    }

    public Integer getPreviousHash() {
        return previousHash;
    }

    public void setPreviousHash(Integer previousHash) {
        this.previousHash = previousHash;
    }
}
