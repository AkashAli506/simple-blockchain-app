package com.akashali.blockchainexample;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;


public class BlockListAdapter extends RecyclerView.Adapter<BlockListAdapter.MyViewHolder> {
    List<Block> newList;
    Context c;
    private OnItemClickListener mListener;
    public BlockListAdapter(List<Block> newList, Context c) {
        this.c=c;
        this.newList=newList;
    }

    public void filterList(ArrayList<Block> newList) {
        this.newList=newList;
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }
    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }
    @NonNull
    @Override
    public BlockListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemrow= LayoutInflater.from(c).inflate(R.layout.row,parent,false);
        return new MyViewHolder(itemrow, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull BlockListAdapter.MyViewHolder holder, int position) {
        holder.Block_no.setText(newList.get(position).getIndex());
        holder.verify.setText(newList.get(position).getIsVerified());
    }
    @Override
    public int getItemCount() {
        return newList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView Block_no;
        public TextView verify;
        public MyViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            Block_no=itemView.findViewById(R.id.Block_no);
            verify=itemView.findViewById(R.id.verify);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
